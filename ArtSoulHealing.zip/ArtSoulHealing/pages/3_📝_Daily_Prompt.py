import streamlit as st
from utils import set_page_config, footer, get_random_prompt

# Set page configuration
set_page_config()

# Daily Prompt page content
st.title("Today's Drawing Prompt")

# Initialize session state for prompt if not exists
if 'current_prompt' not in st.session_state:
    st.session_state.current_prompt = get_random_prompt()

# Display current prompt
st.markdown("## Your Art Prompt:")
prompt_container = st.container(height=200)
with prompt_container:
    st.markdown(f"### {st.session_state.current_prompt}")
    st.markdown("---")
    st.markdown("*Use this prompt as inspiration for today's creative exploration.*")

# Button to get a new prompt
if st.button("Show Another Prompt", type="primary", use_container_width=True):
    st.session_state.current_prompt = get_random_prompt()
    st.rerun()

# Creativity tips section
st.markdown("---")
st.markdown("## Creativity Tips")
tips_expander = st.expander("Click for creativity tips")
with tips_expander:
    st.markdown("""
    - **Start small**: Begin with a simple sketch or outline
    - **Don't aim for perfection**: Focus on the process, not the result
    - **Experiment**: Try different techniques and materials
    - **Set a timer**: Sometimes time constraints can boost creativity
    - **Reflect**: When finished, write down how the process made you feel
    """)

# Footer
footer()
