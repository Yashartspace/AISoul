import streamlit as st
from utils import set_page_config, footer

# Set page configuration
set_page_config()

# Contact/About page content
st.title("About ArtSoul AI")

# Creator information
st.markdown("## Created by Yaswanth Dasari")
st.markdown("World Record Holding Artist | Art Coach | Founder of Inspire & Create LLC")

# Contact information
st.markdown("## Contact Information")
col1, col2 = st.columns(2)

with col1:
    st.markdown("### Email")
    st.markdown("yaswanth.dasari@slu.edu")
    
    st.markdown("### Website")
    st.markdown("inspireandcreate.art")
    
    st.markdown("### Instagram")
    st.markdown("@artist_yaswanth")

with col2:
    # Inspirational quote
    st.markdown("## Inspiration")
    st.markdown("""
    > "Art speaks where words are unable to explain."
    """)
    
    st.markdown("## Mission")
    st.markdown("""
    ArtSoul AI was created to help people on their journey of self-discovery and healing through art. 
    We believe that creativity is a powerful tool for personal growth, emotional expression, and mental wellness.
    """)

# About the App section
st.markdown("---")
st.markdown("## About ArtSoul AI")
st.markdown("""
ArtSoul AI is a digital platform that combines art therapy principles with technology to offer:

- **Daily creative prompts** to spark inspiration
- **AI mentorship** for artistic guidance
- **Progress tracking** to celebrate your creative journey
- **A supportive community** for sharing your work

Whether you're a seasoned artist or just beginning to explore your creative potential, 
ArtSoul AI provides the tools and encouragement to help you express yourself through art.
""")

# Footer
footer()
