import streamlit as st
from utils import set_page_config, footer, increase_level
from PIL import Image
import io

# Set page configuration
set_page_config()

# Upload Artwork page content
st.title("Upload Your Artwork")

# Instructions
st.markdown("Share your creative work inspired by the prompts or your own ideas.")

# File uploader
uploaded_file = st.file_uploader("Choose an image file", type=["jpg", "jpeg", "png"])

# Initialize session state for uploads if not exists
if 'uploads' not in st.session_state:
    st.session_state.uploads = []

# Process uploaded file
if uploaded_file is not None:
    # Display the image
    image = Image.open(uploaded_file)
    st.image(image, caption="Your uploaded artwork", use_column_width=True)
    
    # Artwork details form
    with st.form("artwork_details"):
        title = st.text_input("Artwork Title (optional)")
        description = st.text_area("Description or Reflections (optional)")
        submit_button = st.form_submit_button("Save Artwork", type="primary")
        
        if submit_button:
            # Add to uploads list with timestamp
            import datetime
            timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            
            # Increase level
            increase_level()
            
            # Convert image to bytes for storage in session state
            img_bytes = io.BytesIO()
            image.save(img_bytes, format=image.format)
            
            # Add to uploads
            st.session_state.uploads.append({
                "title": title if title else "Untitled",
                "description": description,
                "timestamp": timestamp,
                "image": img_bytes.getvalue()
            })
            
            # Success message
            st.success("Artwork uploaded successfully! AI feedback coming soon.")
            
            # Level up notification
            st.balloons()
            st.info(f"Congratulations! You've advanced to Level {st.session_state.user_level}.")

# Previously uploaded artwork section
if st.session_state.uploads:
    st.markdown("---")
    st.markdown("## Your Artwork Gallery")
    
    # Create a grid for displaying thumbnails
    cols = st.columns(3)
    
    for i, artwork in enumerate(reversed(st.session_state.uploads)):
        with cols[i % 3]:
            # Convert bytes back to image
            img = Image.open(io.BytesIO(artwork["image"]))
            st.image(img, caption=artwork["title"], use_column_width=True)
            st.markdown(f"*Uploaded: {artwork['timestamp']}*")

# Footer
footer()
