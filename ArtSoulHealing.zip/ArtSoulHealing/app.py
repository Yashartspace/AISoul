import streamlit as st
from utils import set_page_config

# Set page configuration
set_page_config()

# Home page content
st.title("Welcome to ArtSoul AI – Healing Through Creativity")

# Welcome message
st.markdown("### Welcome to ArtSoul AI, your personal art therapy and creativity coach.")

# Create two columns for layout
col1, col2 = st.columns([3, 2])

with col1:
    # Creator details
    st.markdown("#### Created by Yaswanth Dasari")
    st.markdown("World Record Holding Artist | Art Coach | Founder of Inspire & Create LLC")
    
    # Contact info
    st.markdown("#### Contact Information")
    st.markdown("Email: yaswanth.dasari@slu.edu")
    st.markdown("Website: inspireandcreate.art")
    st.markdown("Instagram: @artist_yaswanth")

    # Motivational sub-heading
    st.markdown("### Create. Reflect. Heal. One brushstroke at a time.")

with col2:
    # Display current user progress
    st.markdown("### Your Progress")
    
    # Initialize session state for level if not exists
    if 'user_level' not in st.session_state:
        st.session_state.user_level = 1
    
    # Progress indicator
    st.info(f"Current Level: Beginner (Level {st.session_state.user_level})")
    st.progress(st.session_state.user_level / 10)  # Simple progress visualization
    
    # Navigation help
    st.markdown("### Navigation")
    st.markdown("Use the sidebar to navigate through the app's features.")

# Footer
st.markdown("---")
st.markdown("<div style='text-align: center;'>ArtSoul AI © 2025 | Created by Yaswanth Dasari</div>", unsafe_allow_html=True)
