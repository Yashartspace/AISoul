import streamlit as st
from utils import set_page_config, footer

# Set page configuration
set_page_config()

# Art Chat AI page content
st.title("Talk to Your Art Mentor AI")

# Chat interface
st.markdown("### Ask your art mentor for advice, inspiration, or critique")

# Initialize chat history if it doesn't exist
if 'chat_history' not in st.session_state:
    st.session_state.chat_history = []

# Display chat history
for message in st.session_state.chat_history:
    with st.chat_message(message["role"]):
        st.markdown(message["content"])

# Get user input
user_input = st.chat_input("Ask something about art or creativity...")

if user_input:
    # Display user message
    with st.chat_message("user"):
        st.markdown(user_input)
    
    # Add user message to chat history
    st.session_state.chat_history.append({"role": "user", "content": user_input})
    
    # Display AI response
    with st.chat_message("assistant"):
        ai_response = "Hello! I'm your creative guide. Let's overcome art blocks and unlock new ideas together!"
        st.markdown(ai_response)
    
    # Add AI response to chat history
    st.session_state.chat_history.append({"role": "assistant", "content": ai_response})

# Integration note
st.markdown("---")
st.markdown("*AI integration with DeepSeek Chat or OpenAI API coming soon.*")

# Footer
footer()
