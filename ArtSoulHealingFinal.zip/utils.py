import streamlit as st
import random

def set_page_config():
    """Set the page configuration for all pages."""
    st.set_page_config(
        page_title="ArtSoul AI",
        page_icon="🎨",
        layout="wide",
        initial_sidebar_state="expanded"
    )

def footer():
    """Display footer on all pages."""
    st.markdown("---")
    st.markdown("<div style='text-align: center;'>ArtSoul AI © 2025 | Created by Yaswanth Dasari</div>", unsafe_allow_html=True)

def get_random_prompt():
    """Return a random art prompt from the predefined list."""
    prompts = [
        "Draw a memory you never want to forget.",
        "Sketch a feeling you can't describe with words.",
        "Imagine your dream world and draw it.",
        "Create a portrait of yourself 10 years in the future.",
        "Express the concept of hope using only lines and shapes."
    ]
    return random.choice(prompts)

def increase_level():
    """Increase user level by 1."""
    if 'user_level' not in st.session_state:
        st.session_state.user_level = 1
    else:
        st.session_state.user_level += 1
